/** @typedef {import('./types').WaveObject} WaveObject */
/**
 * @typedef {import('./types').OnlineRecognizerResult} OnlineRecognizerResult
 */
/**
 * @typedef {import('./types').OfflineRecognizerResult} OfflineRecognizerResult
 */

const addon = require('./addon.js')
const streaming_asr = require('./streaming-asr.js');
const non_streaming_asr = require('./non-streaming-asr.js');
const non_streaming_tts = require('./non-streaming-tts.js');
const vad = require('./vad.js');
const slid = require('./spoken-language-identification.js');
const sid = require('./speaker-identification.js');
const at = require('./audio-tagg.js');
const punct = require('./punctuation.js');
const kws = require('./keyword-spotter.js');
const sd = require('./non-streaming-speaker-diarization.js');
const speech_denoiser = require('./non-streaming-speech-denoiser.js');

module.exports = {
  OnlineRecognizer : streaming_asr.OnlineRecognizer,
  OfflineRecognizer : non_streaming_asr.OfflineRecognizer,
  OfflineTts : non_streaming_tts.OfflineTts,
  GenerationConfig : non_streaming_tts.GenerationConfig,
  readWave : addon.readWave,
  writeWave : addon.writeWave,
  Display : streaming_asr.Display,
  Vad : vad.Vad,
  CircularBuffer : vad.CircularBuffer,
  SpokenLanguageIdentification : slid.SpokenLanguageIdentification,
  SpeakerEmbeddingExtractor : sid.SpeakerEmbeddingExtractor,
  SpeakerEmbeddingManager : sid.SpeakerEmbeddingManager,
  AudioTagging : at.AudioTagging,
  OfflinePunctuation : punct.OfflinePunctuation,
  OnlinePunctuation : punct.OnlinePunctuation,
  KeywordSpotter : kws.KeywordSpotter,
  OfflineSpeakerDiarization : sd.OfflineSpeakerDiarization,
  OfflineSpeechDenoiser : speech_denoiser.OfflineSpeechDenoiser,
  version : addon.version,
  gitSha1 : addon.gitSha1,
  gitDate : addon.gitDate,
}
