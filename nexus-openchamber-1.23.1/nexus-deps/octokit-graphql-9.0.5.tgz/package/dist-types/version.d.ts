export declare const VERSION = "9.0.5";
