const intRegex = /^-?\d+$/;
const noiseValue = /^-?\d+n+$/; // Noise - strings that match the custom format before being converted to it
const originalStringify = JSON.stringify;
const originalParse = JSON.parse;
const customFormat = /^-?\d+n$/;

const bigIntsStringify = /([\[:])?"(-?\d+)n"($|\s*[,\}\]])/g;
const noiseStringify = /([\[:])?("-?\d+n+)n("$|"\s*[,\}\]])/g;

/**
 * @typedef {(this: any, key: string | number | undefined, value: any) => any} Replacer
 * @typedef {(key: string | number | undefined, value: any, context?: { source: string }) => any} Reviver
 */

/**
 * Checks if a value is unstringifiable according to native JSON.stringify rules.
 *
 * @param {any} val The value to check.
 * @returns {boolean} True if the value is undefined, a function, or a symbol.
 */
const isUnstringifiable = (val) =>
  val === undefined || typeof val === "function" || typeof val === "symbol";

/**
 * Checks if a value is a native JSON.rawJSON object (Node.js 22+).
 *
 * @param {any} val The value to check.
 * @returns {boolean} True if the value is a RawJSON instance.
 */
const isRawJSON = (val) =>
  val !== null &&
  typeof val === "object" &&
  val.constructor &&
  val.constructor.name === "RawJSON";

/**
 * Iteratively converts a JS value to a JSON string.
 * Used as a fallback when the native JSON.stringify hits the Maximum Call Stack size.
 * Fully compliant with JSON formatting (space), replacers, and toJSON behaviors.
 *
 * @param {any} rootValue The value to stringify.
 * @param {Replacer | Array<string | number> | null} [replacer] User's custom replacer function.
 * @param {string | number} [spaceParam] Indentation for pretty-printing.
 * @returns {string | undefined} The generated JSON string.
 */
const stringifyIteratively = (rootValue, replacer, spaceParam) => {
  let space = "";

  if (typeof spaceParam === "number") {
    space = " ".repeat(Math.min(10, Math.max(0, Math.floor(spaceParam))));
  } else if (typeof spaceParam === "string") {
    space = spaceParam.slice(0, 10);
  }

  const isFunctionReplacer = typeof replacer === "function";
  const propertyList = Array.isArray(replacer)
    ? new Set(replacer.map(String))
    : null;

  /**
   * Prepares a value for stringification by resolving toJSON, handling BigInts,
   * applying custom replacers, and unwrapping primitive objects.
   *
   * @param {object|Array} parent The parent object or array holding the value.
   * @param {string} key The key associated with the value.
   * @param {any} val The raw value to process.
   * @returns {any} The processed value ready for stringification.
   */
  const prepareVal = (parent, key, val) => {
    const isObject = val !== null && typeof val === "object";
    const hasToJSON = isObject && typeof val.toJSON === "function";

    if (hasToJSON) {
      val = val.toJSON(key);
    }

    const isNoise = typeof val === "string" && noiseValue.test(val);

    if (isNoise) return val + "n";

    const isBigInt = typeof val === "bigint";

    if (isBigInt) {
      const supportsRawJSON = "rawJSON" in JSON;

      if (supportsRawJSON) return JSON.rawJSON(val.toString());

      return val.toString() + "n";
    }

    if (isFunctionReplacer) {
      val = replacer.call(parent, key, val);
    }

    const isPostReplacerObject = val !== null && typeof val === "object";

    if (isPostReplacerObject) {
      const isPrimitiveWrapper =
        val instanceof Number ||
        val instanceof String ||
        val instanceof Boolean;

      if (isPrimitiveWrapper) {
        val = val.valueOf();
      }
    }

    return val;
  };

  const rootProcessed = prepareVal({ "": rootValue }, "", rootValue);

  if (isUnstringifiable(rootProcessed)) {
    return undefined;
  }

  const isRootPrimitive =
    rootProcessed === null || typeof rootProcessed !== "object";
  const isRootNativeRawJSON = isRawJSON(rootProcessed);

  if (isRootPrimitive || isRootNativeRawJSON) {
    return originalStringify(rootProcessed);
  }

  const chunks = [];
  let level = 0;

  const stack = [
    {
      parent: { "": rootProcessed },
      key: "",
      val: rootProcessed,
      isArray: Array.isArray(rootProcessed),
      keys: Array.isArray(rootProcessed) ? null : Object.keys(rootProcessed),
      index: 0,
      first: true,
    },
  ];

  const visited = new WeakSet([rootProcessed]);

  while (stack.length > 0) {
    const node = stack[stack.length - 1];

    if (node.index === 0) {
      chunks.push(node.isArray ? "[" : "{");
      level++;
    }

    let isDone = false;

    if (node.isArray) {
      if (node.index < node.val.length) {
        if (!node.first) chunks.push(",");

        if (space) chunks.push("\n" + space.repeat(level));

        const childRaw = node.val[node.index];
        const childVal = prepareVal(node.val, String(node.index), childRaw);

        if (isUnstringifiable(childVal)) {
          chunks.push("null");
          node.first = false;
          node.index++;
        } else {
          const isComplexObject =
            childVal !== null && typeof childVal === "object";
          const isNativeRaw = isRawJSON(childVal);

          if (isComplexObject && !isNativeRaw) {
            if (visited.has(childVal)) {
              throw new TypeError("Converting circular structure to JSON");
            }

            visited.add(childVal);

            stack.push({
              parent: node.val,
              key: String(node.index),
              val: childVal,
              isArray: Array.isArray(childVal),
              keys: Array.isArray(childVal) ? null : Object.keys(childVal),
              index: 0,
              first: true,
            });

            node.first = false;
            node.index++;
          } else {
            chunks.push(originalStringify(childVal));
            node.first = false;
            node.index++;
          }
        }
      } else {
        isDone = true;
      }
    } else {
      while (node.index < node.keys.length) {
        const k = node.keys[node.index++];

        const isFilteredOutByArray = propertyList && !propertyList.has(k);

        if (isFilteredOutByArray) continue;

        const childRaw = node.val[k];
        const childVal = prepareVal(node.val, k, childRaw);

        if (isUnstringifiable(childVal)) continue;

        if (!node.first) chunks.push(",");

        if (space) {
          chunks.push("\n" + space.repeat(level) + originalStringify(k) + ": ");
        } else {
          chunks.push(originalStringify(k) + ":");
        }

        const isComplexObject =
          childVal !== null && typeof childVal === "object";
        const isNativeRaw = isRawJSON(childVal);

        if (isComplexObject && !isNativeRaw) {
          if (visited.has(childVal)) {
            throw new TypeError("Converting circular structure to JSON");
          }

          visited.add(childVal);

          stack.push({
            parent: node.val,
            key: k,
            val: childVal,
            isArray: Array.isArray(childVal),
            keys: Array.isArray(childVal) ? null : Object.keys(childVal),
            index: 0,
            first: true,
          });

          node.first = false;

          break; // Stop current loop level to process the newly pushed stack node
        } else {
          chunks.push(originalStringify(childVal));
          node.first = false;
        }
      }

      const isNodeFullyProcessed =
        node.index >= node.keys.length && stack[stack.length - 1] === node;

      if (isNodeFullyProcessed) {
        isDone = true;
      }
    }

    if (isDone) {
      level--;

      if (!node.first && space) chunks.push("\n" + space.repeat(level));

      chunks.push(node.isArray ? "]" : "}");
      visited.delete(node.val);
      stack.pop();
    }
  }

  return chunks.join("");
};

/**
 * Converts a JavaScript value to a JSON string.
 *
 * Supports serialization of BigInt values using two strategies:
 * 1. Custom format "123n" → "123" (universal fallback)
 * 2. Native JSON.rawJSON() (Node.js 22+, fastest) when available
 *
 * All other values are serialized exactly like native JSON.stringify().
 *
 * @param {*} value The value to convert to a JSON string.
 * @param {Replacer | Array<string | number> | null} [replacer]
 * A function that alters the behavior of the stringification process,
 * or an array of strings/numbers to indicate properties to exclude.
 * @param {string | number} [space]
 * A string or number to specify indentation or pretty-printing.
 * @returns {string} The JSON string representation.
 */
const JSONStringify = (value, replacer, space) => {
  try {
    const supportsRawJSON = "rawJSON" in JSON;

    if (supportsRawJSON) {
      return originalStringify(
        value,
        (key, val) => {
          if (typeof val === "bigint") return JSON.rawJSON(val.toString());

          const hasFunctionReplacer = typeof replacer === "function";

          if (hasFunctionReplacer) return replacer(key, val);

          const isKeyInArrayReplacer =
            Array.isArray(replacer) && replacer.includes(key);

          if (isKeyInArrayReplacer) return val;

          return val;
        },
        space,
      );
    }

    if (!value) return originalStringify(value, replacer, space);

    const convertedToCustomJSON = originalStringify(
      value,
      (key, val) => {
        const isNoise = typeof val === "string" && noiseValue.test(val);

        if (isNoise) return val.toString() + "n"; // Mark noise values with additional "n" to offset the deletion of one "n" during the processing

        if (typeof val === "bigint") return val.toString() + "n";

        const hasFunctionReplacer = typeof replacer === "function";

        if (hasFunctionReplacer) return replacer(key, val);

        const isKeyInArrayReplacer =
          Array.isArray(replacer) && replacer.includes(key);

        if (isKeyInArrayReplacer) return val;

        return val;
      },
      space,
    );

    const processedJSON = convertedToCustomJSON.replace(
      bigIntsStringify,
      "$1$2$3",
    ); // Delete one "n" off the end of every BigInt value

    const denoisedJSON = processedJSON.replace(noiseStringify, "$1$2$3"); // Remove one "n" off the end of every noisy string

    return denoisedJSON;
  } catch (error) {
    if (error instanceof RangeError) {
      const convertedJSON = stringifyIteratively(value, replacer, space);

      if (convertedJSON === undefined) return undefined;

      const supportsRawJSON = "rawJSON" in JSON;

      if (supportsRawJSON) return convertedJSON;

      const processedJSON = convertedJSON.replace(bigIntsStringify, "$1$2$3");

      return processedJSON.replace(noiseStringify, "$1$2$3");
    }

    throw error;
  }
};

const featureCache = new Map();

/**
 * Detects if the current JSON.parse implementation supports the context.source feature.
 *
 * Uses toString() fingerprinting to cache results and automatically detect runtime
 * replacements of JSON.parse (polyfills, mocks, etc.).
 *
 * @returns {boolean} true if context.source is supported, false otherwise.
 */
const isContextSourceSupported = () => {
  const parseFingerprint = JSON.parse.toString();

  if (featureCache.has(parseFingerprint)) {
    return featureCache.get(parseFingerprint);
  }

  try {
    const result = JSON.parse(
      "1",
      (_, __, context) => !!context?.source && context.source === "1",
    );
    featureCache.set(parseFingerprint, result);

    return result;
  } catch {
    featureCache.set(parseFingerprint, false);

    return false;
  }
};

/**
 * Reviver function that converts custom-format BigInt strings back to BigInt values.
 * Also handles "noise" strings that accidentally match the BigInt format.
 *
 * @param {string | number | undefined} key The object key.
 * @param {*} value The value being parsed.
 * @param {object} [context] Parse context (if supported by JSON.parse).
 * @param {Reviver} [userReviver] User's custom reviver function.
 * @returns {any} The transformed value.
 */
const convertMarkedBigIntsReviver = (key, value, context, userReviver) => {
  const isCustomFormatBigInt =
    typeof value === "string" && customFormat.test(value);

  if (isCustomFormatBigInt) return BigInt(value.slice(0, -1));

  const isNoiseValue = typeof value === "string" && noiseValue.test(value);
  if (isNoiseValue) return value.slice(0, -1);

  const hasUserReviver = typeof userReviver === "function";

  if (!hasUserReviver) return value;

  return userReviver(key, value, context);
};

/**
 * Fast JSON.parse implementation (~2x faster than classic fallback).
 * Uses JSON.parse's context.source feature to detect integers and convert
 * large numbers directly to BigInt without string manipulation.
 *
 * Does not support legacy custom format from v1 of this library.
 *
 * @param {string} text JSON string to parse.
 * @param {Reviver} [reviver] Transform function to apply to each value.
 * @returns {any} Parsed JavaScript value.
 */
const JSONParseV2 = (text, reviver) => {
  return JSON.parse(text, (key, value, context) => {
    const isNumber = typeof value === "number";
    const isOutOfBounds =
      value > Number.MAX_SAFE_INTEGER || value < Number.MIN_SAFE_INTEGER;
    const isBigNumber = isNumber && isOutOfBounds;
    const isInt = context && intRegex.test(context.source);
    const isBigInt = isBigNumber && isInt;

    if (isBigInt) return BigInt(context.source);

    const hasCustomReviver = typeof reviver === "function";

    if (!hasCustomReviver) return value;

    return reviver(key, value, context);
  });
};

const MAX_INT = Number.MAX_SAFE_INTEGER.toString();
const MAX_DIGITS = MAX_INT.length;
const stringsOrLargeNumbers =
  /"(?:[^"\\]|\\.)*"|-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?/g;
const noiseValueWithQuotes = /^"-?\d+n+"$/; // Noise - strings that match the custom format before being converted to it

/**
 * Iteratively traverses the parsed object bottom-up (post-order),
 * emulating the native JSON.parse reviver behavior.
 * This avoids Call Stack overflows (RangeError) on deeply nested structures.
 *
 * @param {any} parsed The natively parsed JSON object.
 * @param {Reviver} [userReviver] User's custom reviver function.
 * @returns {any} The fully processed object.
 */
const applyReviverIteratively = (parsed, userReviver) => {
  const rootHolder = { "": parsed };
  const stack = [{ parent: rootHolder, key: "", visited: false }];

  while (stack.length > 0) {
    const node = stack[stack.length - 1];

    if (!node.visited) {
      node.visited = true;

      const value = node.parent[node.key];
      const isComplexObject = value !== null && typeof value === "object";

      if (isComplexObject) {
        const keys = Object.keys(value);

        for (let i = keys.length - 1; i >= 0; i--) {
          stack.push({ parent: value, key: keys[i], visited: false });
        }
      }
    } else {
      const { parent, key } = node;
      let value = parent[key];

      if (typeof value === "string") {
        const isCustomFormatBigInt = customFormat.test(value);

        if (isCustomFormatBigInt) {
          value = BigInt(value.slice(0, -1));
        } else {
          const isNoise = noiseValue.test(value);

          if (isNoise) value = value.slice(0, -1);
        }
      }

      const hasUserReviver = typeof userReviver === "function";

      if (hasUserReviver) {
        value = userReviver.call(parent, key, value);
      }

      const isDeleted = value === undefined;

      if (isDeleted) {
        delete parent[key];
      } else {
        parent[key] = value;
      }

      stack.pop();
    }
  }

  return rootHolder[""];
};

/**
 * Pre-processes the JSON string to mark large numbers with an 'n' suffix.
 *
 * @param {string} text The raw JSON string.
 * @returns {string} The serialized string with marked BigInts.
 */
const serializeBigInts = (text) => {
  return text.replace(
    stringsOrLargeNumbers,
    (match, digits, fractional, exponential) => {
      const isString = match[0] === '"';
      const isNoise = isString && noiseValueWithQuotes.test(match);

      if (isNoise) return match.substring(0, match.length - 1) + 'n"'; // Mark noise values with additional "n" to offset the deletion of one "n" during the processing

      const hasFractionalOrExponential = fractional || exponential;

      // With a fixed number of digits, we can correctly use lexicographical comparison to do a numeric comparison
      const isLessThanMaxSafeInt =
        digits &&
        (digits.length < MAX_DIGITS ||
          (digits.length === MAX_DIGITS && digits <= MAX_INT));

      const isStandardValue =
        isString || hasFractionalOrExponential || isLessThanMaxSafeInt;

      if (isStandardValue) return match;

      return '"' + match + 'n"';
    },
  );
};

/**
 * Converts a JSON string into a JavaScript value.
 *
 * Supports parsing of large integers using two strategies:
 * 1. Classic fallback: Marks large numbers with "123n" format, then converts to BigInt
 * 2. Fast path (JSONParseV2): Uses context.source feature (~2x faster) when available
 *
 * All other JSON values are parsed exactly like native JSON.parse().
 *
 * @param {string} text A valid JSON string.
 * @param {Reviver} [reviver]
 * A function that transforms the results. This function is called for each member
 * of the object. If a member contains nested objects, the nested objects are
 * transformed before the parent object is.
 * @returns {any} The parsed JavaScript value.
 * @throws {SyntaxError} If text is not valid JSON.
 */
const JSONParse = (text, reviver) => {
  if (!text) return originalParse(text, reviver);

  try {
    if (isContextSourceSupported()) return JSONParseV2(text, reviver); // Shortcut to a faster (2x) and simpler version

    // Find and mark big numbers with "n"
    const serializedData = serializeBigInts(text);

    return originalParse(serializedData, (key, value, context) =>
      convertMarkedBigIntsReviver(key, value, context, reviver),
    );
  } catch (error) {
    if (error instanceof RangeError) {
      const serializedData = serializeBigInts(text);
      const parsed = originalParse(serializedData);

      return applyReviverIteratively(parsed, reviver);
    }

    throw error;
  }
};

export { JSONStringify, JSONParse };
